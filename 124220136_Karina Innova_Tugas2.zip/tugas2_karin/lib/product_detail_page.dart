import 'package:flutter/material.dart';

class ProductDetailPage extends StatelessWidget {
  final String productName;
  final int productPrice;
  final String productImage; 

  ProductDetailPage({
    required this.productName,
    required this.productPrice,
    required this.productImage, 
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(productName),
        backgroundColor: Colors.pink[300], 
      ),
      backgroundColor: Colors.white, 
      body: SingleChildScrollView( 
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 250,
              decoration: BoxDecoration(
                color: Colors.white, 
                borderRadius: BorderRadius.circular(8), 
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.2),
                    spreadRadius: 2,
                    blurRadius: 10,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  productImage,
                  width: double.infinity,
                  height: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(height: 20),
            Text(
              productName,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            Row(
              children: [
                Text("Rating: ", style: TextStyle(fontSize: 16)),
                Icon(Icons.star, color: Colors.amber),
                Icon(Icons.star, color: Colors.amber),
                Icon(Icons.star, color: Colors.amber),
              ],
            ),
            SizedBox(height: 20),
            Text("Deskripsi Product: ", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text("Produk perawatan kulit kami dirancang untuk memberi nutrisi, menghidrasi, dan melindungi kulit Anda dengan bahan-bahan terbaik yang diambil dari alam dan didukung oleh inovasi ilmiah."),
            SizedBox(height: 20),
            Text("Harga: \Rp.${productPrice}", style: TextStyle(fontSize: 24, color: Colors.pink[300])),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Pembelian berhasil!')),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink[300], 
                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 30),
              ),
              child: Text(
                "Buy",
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.black, 
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
