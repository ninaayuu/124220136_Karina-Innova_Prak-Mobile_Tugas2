import 'package:flutter/material.dart';
import 'profile_page.dart'; 
import 'product_detail_page.dart';

class HomePage extends StatelessWidget {
  final String username;

  HomePage({required this.username});

  final List<String> productImages = [
    'assets/images/product1.jpeg', 
    'assets/images/product2.jpeg', 
    'assets/images/product3.jpeg', 
    'assets/images/product4.jpeg', 
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Karin Elegance Beauty CO"),
        backgroundColor: Colors.pink[200], 
        actions: [
          // Tombol untuk mengakses ProfilePage
          IconButton(
            icon: Icon(Icons.person, color: Colors.white), 
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProfilePage(username: username),
                ),
              );
            },
          ),
        ],
      ),
      backgroundColor: Colors.white, 
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Welcome, $username!',
              style: TextStyle(fontSize: 18, color: Colors.pink[300]), 
            ),
          ),
          Expanded(
            child: GridView.count(
              crossAxisCount: 2,
              children: List.generate(4, (index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProductDetailPage(
                          productName: 'Product $index',
                          productPrice: (index + 1) * 100,
                          productImage: productImages[index],
                        ),
                      ),
                    );
                  },
                  child: Card(
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12), 
                    ),
                    color: Colors.pink[50], 
                    child: Column(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12), 
                            child: Image.asset(
                              productImages[index], 
                              width: double.infinity, 
                              fit: BoxFit.cover, 
                            ),
                          ),
                        ),
                        Text(
                          'Product $index',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                        ),
                        Text(
                          'Harga : Rp.${(index + 1) * 100}',
                          style: TextStyle(fontSize: 14, color: Colors.pink[300]), 
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}
