package com.example.tugas2_karin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
